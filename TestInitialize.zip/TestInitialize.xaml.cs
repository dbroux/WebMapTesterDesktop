﻿using ESRI.ArcGIS.Client;
using System;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WebMapMVVM
{
	/// <summary>
	/// Interaction logic for TestInitialize.xaml
	/// </summary>
	public partial class TestInitialize : UserControl
	{
		public TestInitialize()
		{
			InitializeComponent();
			InitFeatureLayer();
		}

		private void InitFeatureLayer()
		{
			var featurelayer = new FeatureLayer
			{
				Url = "http://services.arcgisonline.com/ArcGIS/rest/services/Demographics/USA_Median_Age/MapServer/4",
				MaxAllowableOffset = 1000000,
				IgnoreServiceScaleRange = true
			};
			featurelayer.Initialized += featurelayer_Initialized;
			featurelayer.Initialize();
		}

		void featurelayer_Initialized(object sender, EventArgs e)
		{
			AddLayersToMap(sender as Layer);
		}

		private async void AddLayersToMap(Layer layer)
		{
			await Task.Delay(1000); // to be sure the featurelayer.Initialize(); process is over
			MyMap.Layers.Add(new ArcGISTiledMapServiceLayer { Url = "http://services.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer" });
			MyMap.Layers.Add(layer);
		}
	}
}
