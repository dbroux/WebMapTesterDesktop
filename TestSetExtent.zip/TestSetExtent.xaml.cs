﻿using System.Windows;
using ESRI.ArcGIS.Client;
using System;
using System.Threading.Tasks;
using System.Windows.Controls;
using ESRI.ArcGIS.Client.Geometry;

namespace WebMapMVVM
{
	/// <summary>
	/// Interaction logic for TestSetExtent.xaml
	/// </summary>
	public partial class TestSetExtent : UserControl
	{
		public TestSetExtent()
		{
			InitializeComponent();
		}

		private bool _ok = false;
		private void InitExtent(object sender, RoutedEventArgs e)
		{
			MyMap.PropertyChanged += MyMap_PropertyChanged;
			MyMap.Extent = new Envelope(0, 10, 0, 10) { SpatialReference = new SpatialReference(4326)};
			MyMap.Layers.Add(new ArcGISTiledMapServiceLayer { Url = "http://services.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer" });
			MyMap.Layers.LayersInitialized += Layers_LayersInitialized;
		}

		void Layers_LayersInitialized(object sender, EventArgs args)
		{
			if (!_ok)
				MessageBox.Show("KO. PropertyChanged event not received");
		}

		void MyMap_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
		{
			if (e.PropertyName == "SpatialReference")
			{
				_ok = true;
				MessageBox.Show("OK. PropertyChanged event received");
			}
		}

	}
}
